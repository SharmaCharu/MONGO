package com.SpringMongo.SpringMongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Users")
public class UserModel {
	
	@Id
	private String id;
	private String name;
	private String dept;
	private String rep_man;
	public UserModel( String name, String dept, String rep_man) {
		super();
		
		this.name = name;
		this.dept = dept;
		this.rep_man = rep_man;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public void setUsername(String name) {
		this.name = name;
	}
	public String getdept() {
		return dept;
	}
	public void setdept(String dept) {
		this.dept = dept;
	}
	public String getrep_man() {
		return rep_man;
	}
	public void setrep_man(String rep_man) {
		this.rep_man = rep_man;
	}
	
	
	

}
