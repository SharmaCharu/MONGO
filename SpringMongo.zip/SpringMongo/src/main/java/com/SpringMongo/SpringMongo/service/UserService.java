package com.SpringMongo.SpringMongo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringMongo.SpringMongo.model.UserModel;
import com.SpringMongo.SpringMongo.repository.UserRepo;

@Service
public class UserService {
	
	@Autowired
	UserRepo userRepo;
	
	public String createUser(String name, String dep, String rep_man) {
		UserModel user=new UserModel(name, dep, rep_man);
	    userRepo.save(user);
		return name;
		
	}
	public List<UserModel> list(){
		return userRepo.findAll();
	}
	
	public String updateUser(String name, String dep, String rep_man) {
		Users new_user=new User();
		
		new_user
		
		
	}
}
