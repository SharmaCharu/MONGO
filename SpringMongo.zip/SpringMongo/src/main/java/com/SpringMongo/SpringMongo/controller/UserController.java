package com.SpringMongo.SpringMongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpringMongo.SpringMongo.model.UserModel;
import com.SpringMongo.SpringMongo.service.UserService;

@RestController

public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/addDetails")
	
	public String addUser(
			
			@RequestParam("name") String uname,
            @RequestParam("dept") String dept,
            @RequestParam("rep_man") String rep_man
            ) {
		return userService.createUser(uname, dept, rep_man);
	}
	
	@GetMapping("/userDetails")
	
	public List<UserModel> userDetails() {
		return userService.list();
	}
	@PutMapping("/{id}")
	public String updateUser(
		@RequestParam("name") String uname,
		@RequestParam("dept") String dept,
		@RequestParam("rep_man") String rep_man,
		@PathVariable String id
		
	) {
		return userService.updateUser(uname, dept, rep_man);
	}
	
	@DeleteMapping("/{id}")
	public String deleteUser(@PathVariable String id) {
		return userService.deleteUser(id);
	}
}

